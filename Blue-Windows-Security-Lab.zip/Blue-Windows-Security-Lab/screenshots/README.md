# Screenshots

Store only sanitized screenshots here.

Before uploading a screenshot, remove or blur:
- Target IP addresses
- Attacker/listener IP addresses
- MAC addresses
- Passwords
- Password hashes
- Tokens or keys
- Any other sensitive information

Use descriptive names such as:
- `01-nmap-scan.png`
- `02-smb-enumeration.png`
- `03-ms17-010-check.png`
- `04-meterpreter-session.png`
